"""
generate_data.py
-----------------
Generates a synthetic but realistic e-commerce orders & returns dataset.

Note: This dataset is synthetically generated (not scraped or downloaded)
so the project runs anywhere with no external dependencies or API keys.
The generation logic encodes realistic, literature-backed patterns seen in
real e-commerce returns data (e.g. Apparel/Footwear have the highest return
rates, weekend orders return slightly more, higher price bands correlate
with size/fit related returns). Swap this out for a real dataset (e.g.
Kaggle's "Brazilian E-Commerce - Olist" or your own company export) by
replacing the CSV in data/orders.csv with the same column schema.
"""

import numpy as np
import pandas as pd
from datetime import timedelta

np.random.seed(42)

N_ORDERS = 12000

CATEGORIES = {
    "Apparel":     {"base_return_rate": 0.28, "price_range": (15, 150)},
    "Footwear":    {"base_return_rate": 0.24, "price_range": (25, 220)},
    "Electronics": {"base_return_rate": 0.09, "price_range": (30, 1200)},
    "Home & Kitchen": {"base_return_rate": 0.07, "price_range": (10, 400)},
    "Beauty":      {"base_return_rate": 0.05, "price_range": (5, 90)},
    "Sports":      {"base_return_rate": 0.11, "price_range": (10, 300)},
    "Books":       {"base_return_rate": 0.02, "price_range": (5, 60)},
}

RETURN_REASONS = [
    "Wrong size / fit",
    "Not as described",
    "Changed mind",
    "Damaged / defective",
    "Better price found",
    "Late delivery",
    "Wrong item shipped",
]

REASON_WEIGHTS_BY_CATEGORY = {
    "Apparel":        [0.45, 0.15, 0.15, 0.08, 0.05, 0.05, 0.07],
    "Footwear":       [0.50, 0.12, 0.13, 0.08, 0.05, 0.05, 0.07],
    "Electronics":    [0.05, 0.20, 0.10, 0.35, 0.05, 0.10, 0.15],
    "Home & Kitchen": [0.05, 0.20, 0.20, 0.30, 0.05, 0.10, 0.10],
    "Beauty":         [0.05, 0.30, 0.30, 0.15, 0.05, 0.05, 0.10],
    "Sports":         [0.25, 0.15, 0.20, 0.15, 0.05, 0.10, 0.10],
    "Books":          [0.02, 0.20, 0.30, 0.10, 0.08, 0.20, 0.10],
}

STATES = ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain"]
STATE_WEIGHTS = [0.38, 0.22, 0.16, 0.08, 0.08, 0.05, 0.03]

CHANNELS = ["Mobile App", "Website", "Marketplace"]
CHANNEL_WEIGHTS = [0.55, 0.30, 0.15]


def random_dates(n, start="2025-01-01", end="2025-12-31"):
    start_ts = pd.Timestamp(start)
    end_ts = pd.Timestamp(end)
    days = (end_ts - start_ts).days
    offsets = np.random.randint(0, days, size=n)
    return [start_ts + timedelta(days=int(d)) for d in offsets]


def generate():
    order_id = np.arange(100000, 100000 + N_ORDERS)
    category = np.random.choice(list(CATEGORIES.keys()), size=N_ORDERS,
                                 p=[0.24, 0.14, 0.18, 0.16, 0.12, 0.10, 0.06])
    order_date = random_dates(N_ORDERS)

    price = np.array([
        round(np.random.uniform(*CATEGORIES[c]["price_range"]), 2) for c in category
    ])
    quantity = np.random.choice([1, 1, 1, 2, 2, 3], size=N_ORDERS)
    order_value = np.round(price * quantity, 2)

    customer_emirate = np.random.choice(STATES, size=N_ORDERS, p=STATE_WEIGHTS)
    channel = np.random.choice(CHANNELS, size=N_ORDERS, p=CHANNEL_WEIGHTS)

    is_weekend_order = np.array([d.weekday() >= 5 for d in order_date])

    # Base return probability per category, nudged by price band and weekend effect
    base_rate = np.array([CATEGORIES[c]["base_return_rate"] for c in category])
    price_band_bump = np.where(order_value > 300, 0.04, 0.0)  # pricier items -> slightly more returns
    weekend_bump = np.where(is_weekend_order, 0.02, 0.0)      # weekend impulse buys -> more returns
    return_prob = np.clip(base_rate + price_band_bump + weekend_bump, 0, 0.85)

    is_returned = np.random.binomial(1, return_prob)

    # Return reason, days-to-return, refund amount — only meaningful for returned orders
    return_reason = np.full(N_ORDERS, "", dtype=object)
    days_to_return = np.full(N_ORDERS, np.nan)
    refund_amount = np.full(N_ORDERS, np.nan)

    for cat in CATEGORIES:
        mask = (category == cat) & (is_returned == 1)
        n_cat = mask.sum()
        if n_cat == 0:
            continue
        return_reason[mask] = np.random.choice(
            RETURN_REASONS, size=n_cat, p=REASON_WEIGHTS_BY_CATEGORY[cat]
        )

    returned_mask = is_returned == 1
    # Fit/size and "changed mind" returns tend to happen fast; damaged/defective can take longer
    fast_reasons = {"Wrong size / fit", "Changed mind", "Better price found"}
    days = []
    for reason in return_reason[returned_mask]:
        if reason in fast_reasons:
            days.append(max(1, int(np.random.gamma(2, 2))))
        else:
            days.append(max(1, int(np.random.gamma(3, 3))))
    days_to_return[returned_mask] = days
    refund_amount[returned_mask] = order_value[returned_mask] * np.random.uniform(0.85, 1.0, size=returned_mask.sum())

    df = pd.DataFrame({
        "order_id": order_id,
        "order_date": order_date,
        "category": category,
        "unit_price": price,
        "quantity": quantity,
        "order_value": order_value,
        "customer_emirate": customer_emirate,
        "channel": channel,
        "is_weekend_order": is_weekend_order,
        "is_returned": is_returned.astype(bool),
        "return_reason": return_reason,
        "days_to_return": days_to_return,
        "refund_amount": np.round(refund_amount, 2),
    })

    # Sprinkle a few realistic data-quality issues so the cleaning step has something to do
    dup_rows = df.sample(40, random_state=1)
    df = pd.concat([df, dup_rows], ignore_index=True)  # duplicate orders
    missing_idx = df.sample(frac=0.01, random_state=2).index
    df.loc[missing_idx, "customer_emirate"] = np.nan  # missing values
    df.loc[df.sample(15, random_state=3).index, "unit_price"] = -1  # bad data entry

    return df


if __name__ == "__main__":
    df = generate()
    df.to_csv("data/orders.csv", index=False)
    print(f"Generated {len(df)} rows -> data/orders.csv")
    print(f"Overall return rate (raw): {df['is_returned'].mean():.2%}")
