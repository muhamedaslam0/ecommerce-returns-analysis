"""
returns_analysis.py
--------------------
End-to-end EDA on the e-commerce orders/returns dataset:
1. Load & clean data (duplicates, missing values, bad entries)
2. Compute key return metrics
3. Produce 5 publication-quality charts into charts/
4. Print a plain-text summary of key findings to the console and
   save it to charts/summary.txt
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

plt.style.use("seaborn-v0_8-whitegrid")
plt.rcParams.update({
    "figure.dpi": 150,
    "font.size": 11,
    "axes.titlesize": 14,
    "axes.titleweight": "bold",
    "axes.labelsize": 11,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "legend.fontsize": 10,
})

PALETTE = ["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3", "#937860", "#CCB974"]
ACCENT = "#C44E52"
GREY = "#B0B0B0"


# ---------- 1. Load & clean ----------

def load_and_clean(path="data/orders.csv"):
    df = pd.read_csv(path, parse_dates=["order_date"])

    n_start = len(df)

    # Drop exact duplicate orders
    df = df.drop_duplicates(subset="order_id")

    # Fix bad price entries (negative price -> treat as missing, impute with category median)
    df.loc[df["unit_price"] < 0, "unit_price"] = np.nan
    df["unit_price"] = df.groupby("category")["unit_price"].transform(
        lambda s: s.fillna(s.median())
    )
    df["order_value"] = (df["unit_price"] * df["quantity"]).round(2)

    # Fill missing emirate with "Unknown" rather than dropping rows
    df["customer_emirate"] = df["customer_emirate"].fillna("Unknown")

    df["order_month"] = df["order_date"].dt.to_period("M").dt.to_timestamp()

    n_end = len(df)
    print(f"Cleaning: {n_start} -> {n_end} rows "
          f"({n_start - n_end} duplicate orders removed)")

    return df


# ---------- 2. Metrics ----------

def compute_metrics(df):
    overall_rate = df["is_returned"].mean()

    by_category = (
        df.groupby("category")
        .agg(orders=("order_id", "count"), returns=("is_returned", "sum"))
        .assign(return_rate=lambda d: d["returns"] / d["orders"])
        .sort_values("return_rate", ascending=False)
    )

    lost_revenue = df.loc[df["is_returned"], "refund_amount"].sum()
    total_revenue = df["order_value"].sum()

    return {
        "overall_rate": overall_rate,
        "by_category": by_category,
        "lost_revenue": lost_revenue,
        "total_revenue": total_revenue,
    }


# ---------- 3. Charts ----------

def chart_return_rate_by_category(df, out="charts/01_return_rate_by_category.png"):
    stats = (
        df.groupby("category")["is_returned"].mean().sort_values()
    )
    fig, ax = plt.subplots(figsize=(9, 5.5))
    colors = [ACCENT if v == stats.max() else PALETTE[0] for v in stats.values]
    bars = ax.barh(stats.index, stats.values * 100, color=colors)
    for bar, v in zip(bars, stats.values):
        ax.text(bar.get_width() + 0.4, bar.get_y() + bar.get_height() / 2,
                f"{v:.1%}", va="center", fontsize=10)
    ax.set_title("Apparel & Footwear drive the highest return rates")
    ax.set_xlabel("Return rate (%)")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()


def chart_return_reasons(df, out="charts/02_top_return_reasons.png"):
    reasons = df.loc[df["is_returned"], "return_reason"].value_counts(normalize=True).sort_values()
    fig, ax = plt.subplots(figsize=(9, 5.5))
    colors = [ACCENT if v == reasons.max() else PALETTE[0] for v in reasons.values]
    bars = ax.barh(reasons.index, reasons.values * 100, color=colors)
    for bar, v in zip(bars, reasons.values):
        ax.text(bar.get_width() + 0.4, bar.get_y() + bar.get_height() / 2,
                f"{v:.1%}", va="center", fontsize=10)
    ax.set_title("\"Wrong size / fit\" is the #1 reported return reason")
    ax.set_xlabel("Share of all returns (%)")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()


def chart_monthly_trend(df, out="charts/03_monthly_return_rate_trend.png"):
    monthly = df.groupby("order_month")["is_returned"].mean()
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(monthly.index, monthly.values * 100, marker="o", color=PALETTE[0], linewidth=2)
    ax.axhline(monthly.mean() * 100, color=GREY, linestyle="--", linewidth=1,
               label=f"Yearly avg: {monthly.mean():.1%}")
    ax.set_title("Monthly return rate held steady across 2025")
    ax.set_ylabel("Return rate (%)")
    ax.legend(frameon=True)
    ax.spines[["top", "right"]].set_visible(False)
    fig.autofmt_xdate()
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()


def chart_days_to_return(df, out="charts/04_days_to_return_distribution.png"):
    vals = df.loc[df["is_returned"], "days_to_return"].dropna()
    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.hist(vals, bins=25, color=PALETTE[0], edgecolor="white", alpha=0.9)
    ax.axvline(vals.median(), color=ACCENT, linestyle="--", linewidth=2,
               label=f"Median: {vals.median():.0f} days")
    ax.set_title("Most returns happen within the first 1–2 weeks")
    ax.set_xlabel("Days between order and return")
    ax.set_ylabel("Number of returns")
    ax.legend(frameon=True)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()


def chart_channel_weekend_heatmap(df, out="charts/05_return_rate_channel_x_weekend.png"):
    pivot = df.pivot_table(index="channel", columns="is_weekend_order",
                            values="is_returned", aggfunc="mean")
    pivot.columns = ["Weekday", "Weekend"]
    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(pivot.values * 100, cmap="YlOrRd", aspect="auto")
    ax.set_xticks(range(len(pivot.columns)))
    ax.set_xticklabels(pivot.columns)
    ax.set_yticks(range(len(pivot.index)))
    ax.set_yticklabels(pivot.index)
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            ax.text(j, i, f"{pivot.values[i, j]:.1f}%", ha="center", va="center",
                    color="black", fontsize=11)
    ax.set_title("Weekend orders return slightly more, across all channels")
    fig.colorbar(im, ax=ax, label="Return rate (%)")
    plt.tight_layout()
    plt.savefig(out, bbox_inches="tight")
    plt.close()


# ---------- 4. Main ----------

def main():
    df = load_and_clean()
    m = compute_metrics(df)

    chart_return_rate_by_category(df)
    chart_return_reasons(df)
    chart_monthly_trend(df)
    chart_days_to_return(df)
    chart_channel_weekend_heatmap(df)

    top_cat = m["by_category"].index[0]
    top_cat_rate = m["by_category"].iloc[0]["return_rate"]
    top_reason = df.loc[df["is_returned"], "return_reason"].value_counts(normalize=True).idxmax()
    top_reason_share = df.loc[df["is_returned"], "return_reason"].value_counts(normalize=True).max()

    summary = f"""E-COMMERCE RETURNS ANALYSIS — KEY FINDINGS
==========================================
Total orders analyzed:      {len(df):,}
Overall return rate:        {m['overall_rate']:.1%}
Total order revenue:        AED {m['total_revenue']:,.0f}
Revenue lost to refunds:    AED {m['lost_revenue']:,.0f} ({m['lost_revenue']/m['total_revenue']:.1%} of revenue)

Highest-return category:    {top_cat} ({top_cat_rate:.1%} return rate)
Top return reason overall:  {top_reason} ({top_reason_share:.1%} of all returns)

Return rate by category:
{m['by_category']['return_rate'].apply(lambda x: f'{x:.1%}').to_string()}

RECOMMENDATIONS
----------------
1. Add size guides / fit-prediction tools on Apparel & Footwear product pages
   to cut "wrong size / fit" returns, the single largest driver of refunds.
2. Tighten QC and product photography for Electronics/Home & Kitchen, where
   "not as described" and "damaged / defective" dominate.
3. Most returns land within the first two weeks — a proactive post-purchase
   email at day 3-5 (sizing tips, care instructions) could reduce late regret.
"""
    print(summary)
    with open("charts/summary.txt", "w") as f:
        f.write(summary)


if __name__ == "__main__":
    main()
